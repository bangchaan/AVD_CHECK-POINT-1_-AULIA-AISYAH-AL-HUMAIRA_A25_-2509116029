/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package view;

/**
 *
 * @author MSi-
 */
public class CariLaporanView extends javax.swing.JPanel {

    /**
     * Creates new form CariLaporanView
     */
    private final java.util.List<Integer> idPetugasCombo = new java.util.ArrayList<>();
    private String infoAwal;

    public CariLaporanView() {
        initComponents();
        ViewHelper.namaiKartu(this, "cari", "detail");
        infoAwal = lblInfo.getText();
        ((javax.swing.table.DefaultTableModel) tblHasil.getModel()).setRowCount(0);
        ((javax.swing.table.DefaultTableModel) tblRiwayat.getModel()).setRowCount(0);
        isiCombo();
    }

    private void isiCombo() {
        cmbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"Semua", "Menunggu", "Diproses", "Selesai"}));
        cmbPrioritas.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"Semua", "Tinggi", "Sedang", "Rendah"}));

        javax.swing.DefaultComboBoxModel<String> petugas = new javax.swing.DefaultComboBoxModel<>();
        petugas.addElement("Semua");
        idPetugasCombo.clear();
        for (Object[] p : new dao.SupervisorDAO().getDaftarPetugas()) {
            idPetugasCombo.add((Integer) p[0]);
            petugas.addElement((String) p[1]);
        }
        cmbPetugas.setModel(petugas);
    }

    private static String pilihan(javax.swing.JComboBox<String> combo) {
        return combo.getSelectedIndex() <= 0 ? null : String.valueOf(combo.getSelectedItem());
    }

    /** Menjalankan pencarian sesuai kriteria; kriteria kosong tidak difilter. */
    private void jalankanPencarian() {
        Integer id = null;
        if (!txtId.getText().trim().isEmpty()) {
            int angka = ViewHelper.angka(txtId.getText());
            if (angka < 0) {
                javax.swing.JOptionPane.showMessageDialog(this, "ID laporan tidak valid. Contoh: L-0105");
                return;
            }
            id = angka;
        }

        java.sql.Date dari;
        java.sql.Date sampai;
        try {
            dari = ViewHelper.parseTanggal(txtDari.getText());
            sampai = ViewHelper.parseTanggal(txtSampai.getText());
        } catch (IllegalArgumentException e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Format tanggal tidak valid. Contoh: 01 Okt 2026");
            return;
        }
        if (dari != null && sampai != null && dari.after(sampai)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Rentang tanggal tidak valid.");
            return;
        }

        Integer idPetugas = null;
        int indeks = cmbPetugas.getSelectedIndex();
        if (indeks > 0 && indeks - 1 < idPetugasCombo.size()) {
            idPetugas = idPetugasCombo.get(indeks - 1);
        }
        // Peran Petugas hanya boleh melihat laporan pada penugasannya sendiri.
        Integer batasPetugas = "Petugas".equalsIgnoreCase(peran) ? controller.Sesi.getId() : null;

        java.util.List<Object[]> hasil = new dao.SupervisorDAO().cariLaporan(
                id, dari, sampai, txtFasilitas.getText(),
                pilihan(cmbStatus), pilihan(cmbPrioritas), idPetugas, batasPetugas);

        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tblHasil.getModel();
        model.setRowCount(0);
        for (Object[] d : hasil) {
            model.addRow(new Object[]{
                ViewHelper.kodeLaporan((Integer) d[0]),
                ViewHelper.tanggal((java.util.Date) d[1]),
                d[2], d[3], d[4],
                d[5] == null ? "-" : d[5],
                "Detail"
            });
        }
        lblInfo.setText(hasil.isEmpty() ? "Laporan tidak ditemukan" : infoAwal);
    }

    private void muatDetail(int idLaporan) {
        dao.SupervisorDAO dao = new dao.SupervisorDAO();
        Object[] d = dao.getDetailLaporan(idLaporan);
        lblDetailJudul.setText("Detail Laporan " + ViewHelper.kodeLaporan(idLaporan));
        if (d == null) {
            lblDetailSub.setText("Laporan tidak ditemukan");
        } else {
            lblDetailSub.setText("<html><body style='width:760px'>"
                    + d[2] + " (" + d[3] + ")  ·  " + ViewHelper.tanggal((java.util.Date) d[1])
                    + "  ·  Prioritas " + d[5] + "  ·  Status " + d[6]
                    + "<br>Petugas: " + (d[7] == null ? "-" : d[7])
                    + "<br>Deskripsi: " + d[4] + "</body></html>");
        }
        javax.swing.table.DefaultTableModel model = (javax.swing.table.DefaultTableModel) tblRiwayat.getModel();
        model.setRowCount(0);
        for (Object[] r : dao.getRiwayatLaporan(idLaporan)) {
            model.addRow(new Object[]{
                ViewHelper.waktu((java.util.Date) r[0]), r[1], r[2] == null ? "-" : r[2]});
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlCari = new javax.swing.JPanel();
        lblCariJudul = new javax.swing.JLabel();
        lblCariSub = new javax.swing.JLabel();
        pnlKriteria = new javax.swing.JPanel();
        pnlKriteriaHead = new javax.swing.JPanel();
        lblKriteriaJudul = new javax.swing.JLabel();
        btnReset = new javax.swing.JButton();
        pnlKr1 = new javax.swing.JPanel();
        pnlKrId = new javax.swing.JPanel();
        lblKrId = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        pnlKrDari = new javax.swing.JPanel();
        lblKrDari = new javax.swing.JLabel();
        txtDari = new javax.swing.JTextField();
        pnlKrSampai = new javax.swing.JPanel();
        lblKrSampai = new javax.swing.JLabel();
        txtSampai = new javax.swing.JTextField();
        pnlKr2 = new javax.swing.JPanel();
        pnlKrFas = new javax.swing.JPanel();
        lblKrFas = new javax.swing.JLabel();
        txtFasilitas = new javax.swing.JTextField();
        pnlKrStatus = new javax.swing.JPanel();
        lblKrStatus = new javax.swing.JLabel();
        cmbStatus = new javax.swing.JComboBox<>();
        pnlKrPrioritas = new javax.swing.JPanel();
        lblKrPrioritas = new javax.swing.JLabel();
        cmbPrioritas = new javax.swing.JComboBox<>();
        pnlKrPetugas = new javax.swing.JPanel();
        lblKrPetugas = new javax.swing.JLabel();
        cmbPetugas = new javax.swing.JComboBox<>();
        pnlKrCari = new javax.swing.JPanel();
        lblKrSpasi = new javax.swing.JLabel();
        btnCari = new javax.swing.JButton();
        scr_tblHasil = new javax.swing.JScrollPane();
        tblHasil = new javax.swing.JTable();
        lblInfo = new javax.swing.JLabel();
        pnlDetail = new javax.swing.JPanel();
        lblDetailJudul = new javax.swing.JLabel();
        lblDetailSub = new javax.swing.JLabel();
        pnlDtToolbar = new javax.swing.JPanel();
        btnKembali = new javax.swing.JButton();
        pnlDtRow = new javax.swing.JPanel();
        pnlDtInfo = new javax.swing.JPanel();
        lblDtInfoJudul = new javax.swing.JLabel();
        pnlDtK1 = new javax.swing.JPanel();
        pnlDtK1K = new javax.swing.JLabel();
        pnlDtK1V = new javax.swing.JLabel();
        pnlDtK2 = new javax.swing.JPanel();
        pnlDtK2K = new javax.swing.JLabel();
        pnlDtK2V = new javax.swing.JLabel();
        pnlDtK3 = new javax.swing.JPanel();
        pnlDtK3K = new javax.swing.JLabel();
        pnlDtK3V = new javax.swing.JLabel();
        pnlDtK4 = new javax.swing.JPanel();
        pnlDtK4K = new javax.swing.JLabel();
        pnlDtK4V = new javax.swing.JLabel();
        pnlDtK5 = new javax.swing.JPanel();
        pnlDtK5K = new javax.swing.JLabel();
        pnlDtK5V = new javax.swing.JLabel();
        pnlDtK6 = new javax.swing.JPanel();
        pnlDtK6K = new javax.swing.JLabel();
        pnlDtK6V = new javax.swing.JLabel();
        pnlDtPetugas = new javax.swing.JPanel();
        lblDtPetugasJudul = new javax.swing.JLabel();
        pnlDtP1 = new javax.swing.JPanel();
        pnlDtP1K = new javax.swing.JLabel();
        pnlDtP1V = new javax.swing.JLabel();
        pnlDtP2 = new javax.swing.JPanel();
        pnlDtP2K = new javax.swing.JLabel();
        pnlDtP2V = new javax.swing.JLabel();
        pnlDtP3 = new javax.swing.JPanel();
        pnlDtP3K = new javax.swing.JLabel();
        pnlDtP3V = new javax.swing.JLabel();
        pnlDtP4 = new javax.swing.JPanel();
        pnlDtP4K = new javax.swing.JLabel();
        pnlDtP4V = new javax.swing.JLabel();
        pnlDtRiwayat = new javax.swing.JPanel();
        lblDtRiwayatJudul = new javax.swing.JLabel();
        scr_tblRiwayat = new javax.swing.JScrollPane();
        tblRiwayat = new javax.swing.JTable();

        setLayout(new java.awt.CardLayout());

        pnlCari.setBackground(new java.awt.Color(241, 245, 249));

        lblCariJudul.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        lblCariJudul.setForeground(new java.awt.Color(15, 23, 42));
        lblCariJudul.setText("Cari Laporan");

        lblCariSub.setForeground(new java.awt.Color(100, 116, 139));
        lblCariSub.setText("Kosongkan kriteria yang tidak diperlukan  ·  semua laporan");

        pnlKriteria.setBackground(new java.awt.Color(255, 255, 255));
        pnlKriteria.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(226, 232, 240)));

        pnlKriteriaHead.setOpaque(false);

        lblKriteriaJudul.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblKriteriaJudul.setForeground(new java.awt.Color(15, 23, 42));
        lblKriteriaJudul.setText("Kriteria Pencarian");

        btnReset.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnReset.setForeground(new java.awt.Color(15, 23, 42));
        btnReset.setText("Reset");
        btnReset.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(203, 213, 225)));
        btnReset.setContentAreaFilled(false);
        btnReset.setFocusPainted(false);
        btnReset.setOpaque(true);
        btnReset.addActionListener(this::btnResetActionPerformed);

        javax.swing.GroupLayout pnlKriteriaHeadLayout = new javax.swing.GroupLayout(pnlKriteriaHead);
        pnlKriteriaHead.setLayout(pnlKriteriaHeadLayout);
        pnlKriteriaHeadLayout.setHorizontalGroup(
            pnlKriteriaHeadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKriteriaHeadLayout.createSequentialGroup()
                .addComponent(lblKriteriaJudul)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnReset, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        pnlKriteriaHeadLayout.setVerticalGroup(
            pnlKriteriaHeadLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblKriteriaJudul, javax.swing.GroupLayout.Alignment.CENTER)
            .addComponent(btnReset, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pnlKr1.setOpaque(false);

        pnlKrId.setOpaque(false);

        lblKrId.setForeground(new java.awt.Color(51, 65, 85));
        lblKrId.setText("ID Laporan");

        txtId.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txtId.setForeground(new java.awt.Color(15, 23, 42));
        txtId.setToolTipText("L-0105");
        txtId.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(203, 213, 225)), javax.swing.BorderFactory.createEmptyBorder(0, 12, 0, 12)));

        javax.swing.GroupLayout pnlKrIdLayout = new javax.swing.GroupLayout(pnlKrId);
        pnlKrId.setLayout(pnlKrIdLayout);
        pnlKrIdLayout.setHorizontalGroup(
            pnlKrIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblKrId, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(txtId)
        );
        pnlKrIdLayout.setVerticalGroup(
            pnlKrIdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKrIdLayout.createSequentialGroup()
                .addComponent(lblKrId)
                .addGap(6, 6, 6)
                .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnlKrDari.setOpaque(false);

        lblKrDari.setForeground(new java.awt.Color(51, 65, 85));
        lblKrDari.setText("Tanggal Laporan (dari)");

        txtDari.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txtDari.setForeground(new java.awt.Color(15, 23, 42));
        txtDari.setToolTipText("01 Okt 2026");
        txtDari.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(203, 213, 225)), javax.swing.BorderFactory.createEmptyBorder(0, 12, 0, 12)));

        javax.swing.GroupLayout pnlKrDariLayout = new javax.swing.GroupLayout(pnlKrDari);
        pnlKrDari.setLayout(pnlKrDariLayout);
        pnlKrDariLayout.setHorizontalGroup(
            pnlKrDariLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblKrDari, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(txtDari)
        );
        pnlKrDariLayout.setVerticalGroup(
            pnlKrDariLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKrDariLayout.createSequentialGroup()
                .addComponent(lblKrDari)
                .addGap(6, 6, 6)
                .addComponent(txtDari, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnlKrSampai.setOpaque(false);

        lblKrSampai.setForeground(new java.awt.Color(51, 65, 85));
        lblKrSampai.setText("Tanggal Laporan (sampai)");

        txtSampai.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txtSampai.setForeground(new java.awt.Color(15, 23, 42));
        txtSampai.setToolTipText("02 Nov 2026");
        txtSampai.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(203, 213, 225)), javax.swing.BorderFactory.createEmptyBorder(0, 12, 0, 12)));

        javax.swing.GroupLayout pnlKrSampaiLayout = new javax.swing.GroupLayout(pnlKrSampai);
        pnlKrSampai.setLayout(pnlKrSampaiLayout);
        pnlKrSampaiLayout.setHorizontalGroup(
            pnlKrSampaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblKrSampai, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(txtSampai)
        );
        pnlKrSampaiLayout.setVerticalGroup(
            pnlKrSampaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKrSampaiLayout.createSequentialGroup()
                .addComponent(lblKrSampai)
                .addGap(6, 6, 6)
                .addComponent(txtSampai, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout pnlKr1Layout = new javax.swing.GroupLayout(pnlKr1);
        pnlKr1.setLayout(pnlKr1Layout);
        pnlKr1Layout.setHorizontalGroup(
            pnlKr1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKr1Layout.createSequentialGroup()
                .addComponent(pnlKrId, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
                .addComponent(pnlKrDari, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
                .addComponent(pnlKrSampai, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlKr1Layout.setVerticalGroup(
            pnlKr1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlKrId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(pnlKrDari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(pnlKrSampai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pnlKr2.setOpaque(false);

        pnlKrFas.setOpaque(false);

        lblKrFas.setForeground(new java.awt.Color(51, 65, 85));
        lblKrFas.setText("Fasilitas / Lokasi");

        txtFasilitas.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        txtFasilitas.setForeground(new java.awt.Color(15, 23, 42));
        txtFasilitas.setToolTipText("Nama fasilitas atau lokasi");
        txtFasilitas.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(203, 213, 225)), javax.swing.BorderFactory.createEmptyBorder(0, 12, 0, 12)));

        javax.swing.GroupLayout pnlKrFasLayout = new javax.swing.GroupLayout(pnlKrFas);
        pnlKrFas.setLayout(pnlKrFasLayout);
        pnlKrFasLayout.setHorizontalGroup(
            pnlKrFasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblKrFas, javax.swing.GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE)
            .addComponent(txtFasilitas)
        );
        pnlKrFasLayout.setVerticalGroup(
            pnlKrFasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKrFasLayout.createSequentialGroup()
                .addComponent(lblKrFas)
                .addGap(6, 6, 6)
                .addComponent(txtFasilitas, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnlKrStatus.setOpaque(false);

        lblKrStatus.setForeground(new java.awt.Color(51, 65, 85));
        lblKrStatus.setText("Status");

        cmbStatus.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N

        javax.swing.GroupLayout pnlKrStatusLayout = new javax.swing.GroupLayout(pnlKrStatus);
        pnlKrStatus.setLayout(pnlKrStatusLayout);
        pnlKrStatusLayout.setHorizontalGroup(
            pnlKrStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblKrStatus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(cmbStatus, 0, 150, Short.MAX_VALUE)
        );
        pnlKrStatusLayout.setVerticalGroup(
            pnlKrStatusLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKrStatusLayout.createSequentialGroup()
                .addComponent(lblKrStatus)
                .addGap(6, 6, 6)
                .addComponent(cmbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnlKrPrioritas.setOpaque(false);

        lblKrPrioritas.setForeground(new java.awt.Color(51, 65, 85));
        lblKrPrioritas.setText("Prioritas");

        cmbPrioritas.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N

        javax.swing.GroupLayout pnlKrPrioritasLayout = new javax.swing.GroupLayout(pnlKrPrioritas);
        pnlKrPrioritas.setLayout(pnlKrPrioritasLayout);
        pnlKrPrioritasLayout.setHorizontalGroup(
            pnlKrPrioritasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblKrPrioritas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(cmbPrioritas, 0, 150, Short.MAX_VALUE)
        );
        pnlKrPrioritasLayout.setVerticalGroup(
            pnlKrPrioritasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKrPrioritasLayout.createSequentialGroup()
                .addComponent(lblKrPrioritas)
                .addGap(6, 6, 6)
                .addComponent(cmbPrioritas, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnlKrPetugas.setOpaque(false);

        lblKrPetugas.setForeground(new java.awt.Color(51, 65, 85));
        lblKrPetugas.setText("Petugas");

        cmbPetugas.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N

        javax.swing.GroupLayout pnlKrPetugasLayout = new javax.swing.GroupLayout(pnlKrPetugas);
        pnlKrPetugas.setLayout(pnlKrPetugasLayout);
        pnlKrPetugasLayout.setHorizontalGroup(
            pnlKrPetugasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblKrPetugas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(cmbPetugas, 0, 150, Short.MAX_VALUE)
        );
        pnlKrPetugasLayout.setVerticalGroup(
            pnlKrPetugasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKrPetugasLayout.createSequentialGroup()
                .addComponent(lblKrPetugas)
                .addGap(6, 6, 6)
                .addComponent(cmbPetugas, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pnlKrCari.setOpaque(false);

        lblKrSpasi.setForeground(new java.awt.Color(15, 23, 42));
        lblKrSpasi.setText(" ");

        btnCari.setBackground(new java.awt.Color(37, 99, 235));
        btnCari.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        btnCari.setForeground(new java.awt.Color(255, 255, 255));
        btnCari.setText("Cari");
        btnCari.setBorderPainted(false);
        btnCari.setContentAreaFilled(false);
        btnCari.setFocusPainted(false);
        btnCari.setOpaque(true);
        btnCari.addActionListener(this::btnCariActionPerformed);

        javax.swing.GroupLayout pnlKrCariLayout = new javax.swing.GroupLayout(pnlKrCari);
        pnlKrCari.setLayout(pnlKrCariLayout);
        pnlKrCariLayout.setHorizontalGroup(
            pnlKrCariLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblKrSpasi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnCari, javax.swing.GroupLayout.DEFAULT_SIZE, 76, Short.MAX_VALUE)
        );
        pnlKrCariLayout.setVerticalGroup(
            pnlKrCariLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKrCariLayout.createSequentialGroup()
                .addComponent(lblKrSpasi)
                .addGap(6, 6, 6)
                .addComponent(btnCari, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout pnlKr2Layout = new javax.swing.GroupLayout(pnlKr2);
        pnlKr2.setLayout(pnlKr2Layout);
        pnlKr2Layout.setHorizontalGroup(
            pnlKr2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKr2Layout.createSequentialGroup()
                .addComponent(pnlKrFas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
                .addComponent(pnlKrStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(pnlKrPrioritas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(pnlKrPetugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(pnlKrCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        pnlKr2Layout.setVerticalGroup(
            pnlKr2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlKrFas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(pnlKrStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(pnlKrPrioritas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(pnlKrPetugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(pnlKrCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout pnlKriteriaLayout = new javax.swing.GroupLayout(pnlKriteria);
        pnlKriteria.setLayout(pnlKriteriaLayout);
        pnlKriteriaLayout.setHorizontalGroup(
            pnlKriteriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKriteriaLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(pnlKriteriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlKriteriaHead, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlKr1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlKr2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );
        pnlKriteriaLayout.setVerticalGroup(
            pnlKriteriaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlKriteriaLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(pnlKriteriaHead, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(pnlKr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(pnlKr2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        scr_tblHasil.setBackground(new java.awt.Color(255, 255, 255));
        scr_tblHasil.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(226, 232, 240)));

        tblHasil.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"L-0105", "02 Nov 2026", "Eskalator E-03", "Tinggi", "Menunggu", "-", "Detail"},
                {"L-0104", "01 Nov 2026", "Lift L-02", "Tinggi", "Diproses", "Agus Prasetyo", "Detail"},
                {"L-0103", "31 Okt 2026", "Toilet Pria B", "Sedang", "Menunggu", "-", "Detail"},
                {"L-0102", "30 Okt 2026", "AC Ruang Tunggu A", "Rendah", "Selesai", "Dewi Lestari", "Detail"}
            },
            new String [] {
                "ID", "Tanggal", "Fasilitas", "Prioritas", "Status", "Petugas", "Aksi"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblHasil.setForeground(new java.awt.Color(15, 23, 42));
        tblHasil.setRowHeight(40);
        tblHasil.setFillsViewportHeight(true);
        tblHasil.setGridColor(new java.awt.Color(226, 232, 240));
        tblHasil.setSelectionBackground(new java.awt.Color(219, 234, 254));
        tblHasil.setSelectionForeground(new java.awt.Color(15, 23, 42));
        tblHasil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblHasilMouseClicked(evt);
            }
        });
        scr_tblHasil.setViewportView(tblHasil);

        lblInfo.setForeground(new java.awt.Color(100, 116, 139));
        lblInfo.setText("Klik Detail untuk melihat riwayat progres laporan");

        javax.swing.GroupLayout pnlCariLayout = new javax.swing.GroupLayout(pnlCari);
        pnlCari.setLayout(pnlCariLayout);
        pnlCariLayout.setHorizontalGroup(
            pnlCariLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCariLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(pnlCariLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblCariJudul, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblCariSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlKriteria, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(scr_tblHasil)
                    .addComponent(lblInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(32, 32, 32))
        );
        pnlCariLayout.setVerticalGroup(
            pnlCariLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCariLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblCariJudul)
                .addGap(4, 4, 4)
                .addComponent(lblCariSub)
                .addGap(12, 12, 12)
                .addComponent(pnlKriteria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(scr_tblHasil, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(lblInfo)
                .addGap(24, 24, 24))
        );

        add(pnlCari);

        pnlDetail.setBackground(new java.awt.Color(241, 245, 249));

        lblDetailJudul.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        lblDetailJudul.setForeground(new java.awt.Color(15, 23, 42));
        lblDetailJudul.setText("Detail Laporan L-0104");

        lblDetailSub.setForeground(new java.awt.Color(100, 116, 139));
        lblDetailSub.setText("Informasi laporan, petugas, dan riwayat progres");

        pnlDtToolbar.setOpaque(false);

        btnKembali.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnKembali.setForeground(new java.awt.Color(15, 23, 42));
        btnKembali.setText("← Kembali ke Hasil Pencarian");
        btnKembali.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(203, 213, 225)));
        btnKembali.setContentAreaFilled(false);
        btnKembali.setFocusPainted(false);
        btnKembali.setOpaque(true);
        btnKembali.addActionListener(this::btnKembaliActionPerformed);

        javax.swing.GroupLayout pnlDtToolbarLayout = new javax.swing.GroupLayout(pnlDtToolbar);
        pnlDtToolbar.setLayout(pnlDtToolbarLayout);
        pnlDtToolbarLayout.setHorizontalGroup(
            pnlDtToolbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtToolbarLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnKembali, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        pnlDtToolbarLayout.setVerticalGroup(
            pnlDtToolbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btnKembali, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pnlDtRow.setOpaque(false);

        pnlDtInfo.setBackground(new java.awt.Color(255, 255, 255));
        pnlDtInfo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(226, 232, 240)));

        lblDtInfoJudul.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblDtInfoJudul.setForeground(new java.awt.Color(15, 23, 42));
        lblDtInfoJudul.setText("Informasi Laporan");

        pnlDtK1.setOpaque(false);

        pnlDtK1K.setForeground(new java.awt.Color(100, 116, 139));
        pnlDtK1K.setText("Fasilitas");

        pnlDtK1V.setForeground(new java.awt.Color(15, 23, 42));
        pnlDtK1V.setText("Lift L-02 (Lift)");

        javax.swing.GroupLayout pnlDtK1Layout = new javax.swing.GroupLayout(pnlDtK1);
        pnlDtK1.setLayout(pnlDtK1Layout);
        pnlDtK1Layout.setHorizontalGroup(
            pnlDtK1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtK1Layout.createSequentialGroup()
                .addComponent(pnlDtK1K, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlDtK1V, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDtK1Layout.setVerticalGroup(
            pnlDtK1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDtK1K, javax.swing.GroupLayout.Alignment.CENTER)
            .addComponent(pnlDtK1V, javax.swing.GroupLayout.Alignment.CENTER)
        );

        pnlDtK2.setOpaque(false);

        pnlDtK2K.setForeground(new java.awt.Color(100, 116, 139));
        pnlDtK2K.setText("Lokasi");

        pnlDtK2V.setForeground(new java.awt.Color(15, 23, 42));
        pnlDtK2V.setText("Terminal 2");

        javax.swing.GroupLayout pnlDtK2Layout = new javax.swing.GroupLayout(pnlDtK2);
        pnlDtK2.setLayout(pnlDtK2Layout);
        pnlDtK2Layout.setHorizontalGroup(
            pnlDtK2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtK2Layout.createSequentialGroup()
                .addComponent(pnlDtK2K, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlDtK2V, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDtK2Layout.setVerticalGroup(
            pnlDtK2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDtK2K, javax.swing.GroupLayout.Alignment.CENTER)
            .addComponent(pnlDtK2V, javax.swing.GroupLayout.Alignment.CENTER)
        );

        pnlDtK3.setOpaque(false);

        pnlDtK3K.setForeground(new java.awt.Color(100, 116, 139));
        pnlDtK3K.setText("Tanggal Laporan");

        pnlDtK3V.setForeground(new java.awt.Color(15, 23, 42));
        pnlDtK3V.setText("01 Nov 2026");

        javax.swing.GroupLayout pnlDtK3Layout = new javax.swing.GroupLayout(pnlDtK3);
        pnlDtK3.setLayout(pnlDtK3Layout);
        pnlDtK3Layout.setHorizontalGroup(
            pnlDtK3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtK3Layout.createSequentialGroup()
                .addComponent(pnlDtK3K, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlDtK3V, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDtK3Layout.setVerticalGroup(
            pnlDtK3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDtK3K, javax.swing.GroupLayout.Alignment.CENTER)
            .addComponent(pnlDtK3V, javax.swing.GroupLayout.Alignment.CENTER)
        );

        pnlDtK4.setOpaque(false);

        pnlDtK4K.setForeground(new java.awt.Color(100, 116, 139));
        pnlDtK4K.setText("Prioritas");

        pnlDtK4V.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        pnlDtK4V.setForeground(new java.awt.Color(185, 28, 28));
        pnlDtK4V.setText("Tinggi");

        javax.swing.GroupLayout pnlDtK4Layout = new javax.swing.GroupLayout(pnlDtK4);
        pnlDtK4.setLayout(pnlDtK4Layout);
        pnlDtK4Layout.setHorizontalGroup(
            pnlDtK4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtK4Layout.createSequentialGroup()
                .addComponent(pnlDtK4K, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlDtK4V, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDtK4Layout.setVerticalGroup(
            pnlDtK4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDtK4K, javax.swing.GroupLayout.Alignment.CENTER)
            .addComponent(pnlDtK4V, javax.swing.GroupLayout.Alignment.CENTER)
        );

        pnlDtK5.setOpaque(false);

        pnlDtK5K.setForeground(new java.awt.Color(100, 116, 139));
        pnlDtK5K.setText("Status");

        pnlDtK5V.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        pnlDtK5V.setForeground(new java.awt.Color(29, 78, 216));
        pnlDtK5V.setText("Diproses");

        javax.swing.GroupLayout pnlDtK5Layout = new javax.swing.GroupLayout(pnlDtK5);
        pnlDtK5.setLayout(pnlDtK5Layout);
        pnlDtK5Layout.setHorizontalGroup(
            pnlDtK5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtK5Layout.createSequentialGroup()
                .addComponent(pnlDtK5K, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlDtK5V, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDtK5Layout.setVerticalGroup(
            pnlDtK5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDtK5K, javax.swing.GroupLayout.Alignment.CENTER)
            .addComponent(pnlDtK5V, javax.swing.GroupLayout.Alignment.CENTER)
        );

        pnlDtK6.setOpaque(false);

        pnlDtK6K.setForeground(new java.awt.Color(100, 116, 139));
        pnlDtK6K.setText("Deskripsi");

        pnlDtK6V.setForeground(new java.awt.Color(15, 23, 42));
        pnlDtK6V.setText("Pintu lift tidak menutup rapat dan lantai tidak sejajar.");

        javax.swing.GroupLayout pnlDtK6Layout = new javax.swing.GroupLayout(pnlDtK6);
        pnlDtK6.setLayout(pnlDtK6Layout);
        pnlDtK6Layout.setHorizontalGroup(
            pnlDtK6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtK6Layout.createSequentialGroup()
                .addComponent(pnlDtK6K, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlDtK6V, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDtK6Layout.setVerticalGroup(
            pnlDtK6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDtK6K, javax.swing.GroupLayout.Alignment.CENTER)
            .addComponent(pnlDtK6V, javax.swing.GroupLayout.Alignment.CENTER)
        );

        javax.swing.GroupLayout pnlDtInfoLayout = new javax.swing.GroupLayout(pnlDtInfo);
        pnlDtInfo.setLayout(pnlDtInfoLayout);
        pnlDtInfoLayout.setHorizontalGroup(
            pnlDtInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtInfoLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(pnlDtInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDtInfoJudul, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtK1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtK2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtK3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtK4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtK5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtK6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );
        pnlDtInfoLayout.setVerticalGroup(
            pnlDtInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtInfoLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(lblDtInfoJudul)
                .addGap(10, 10, 10)
                .addComponent(pnlDtK1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(pnlDtK2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(pnlDtK3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(pnlDtK4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(pnlDtK5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(pnlDtK6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        pnlDtPetugas.setBackground(new java.awt.Color(255, 255, 255));
        pnlDtPetugas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(226, 232, 240)));

        lblDtPetugasJudul.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblDtPetugasJudul.setForeground(new java.awt.Color(15, 23, 42));
        lblDtPetugasJudul.setText("Petugas Penanggung Jawab");

        pnlDtP1.setOpaque(false);

        pnlDtP1K.setForeground(new java.awt.Color(100, 116, 139));
        pnlDtP1K.setText("Utama");

        pnlDtP1V.setForeground(new java.awt.Color(15, 23, 42));
        pnlDtP1V.setText("Agus Prasetyo");

        javax.swing.GroupLayout pnlDtP1Layout = new javax.swing.GroupLayout(pnlDtP1);
        pnlDtP1.setLayout(pnlDtP1Layout);
        pnlDtP1Layout.setHorizontalGroup(
            pnlDtP1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtP1Layout.createSequentialGroup()
                .addComponent(pnlDtP1K, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlDtP1V, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDtP1Layout.setVerticalGroup(
            pnlDtP1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDtP1K, javax.swing.GroupLayout.Alignment.CENTER)
            .addComponent(pnlDtP1V, javax.swing.GroupLayout.Alignment.CENTER)
        );

        pnlDtP2.setOpaque(false);

        pnlDtP2K.setForeground(new java.awt.Color(100, 116, 139));
        pnlDtP2K.setText("Pendamping");

        pnlDtP2V.setForeground(new java.awt.Color(15, 23, 42));
        pnlDtP2V.setText("Dewi Lestari");

        javax.swing.GroupLayout pnlDtP2Layout = new javax.swing.GroupLayout(pnlDtP2);
        pnlDtP2.setLayout(pnlDtP2Layout);
        pnlDtP2Layout.setHorizontalGroup(
            pnlDtP2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtP2Layout.createSequentialGroup()
                .addComponent(pnlDtP2K, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlDtP2V, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDtP2Layout.setVerticalGroup(
            pnlDtP2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDtP2K, javax.swing.GroupLayout.Alignment.CENTER)
            .addComponent(pnlDtP2V, javax.swing.GroupLayout.Alignment.CENTER)
        );

        pnlDtP3.setOpaque(false);

        pnlDtP3K.setForeground(new java.awt.Color(100, 116, 139));
        pnlDtP3K.setText("Ditugaskan oleh");

        pnlDtP3V.setForeground(new java.awt.Color(15, 23, 42));
        pnlDtP3V.setText("Budi Santoso");

        javax.swing.GroupLayout pnlDtP3Layout = new javax.swing.GroupLayout(pnlDtP3);
        pnlDtP3.setLayout(pnlDtP3Layout);
        pnlDtP3Layout.setHorizontalGroup(
            pnlDtP3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtP3Layout.createSequentialGroup()
                .addComponent(pnlDtP3K, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlDtP3V, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlDtP3Layout.setVerticalGroup(
            pnlDtP3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDtP3K, javax.swing.GroupLayout.Alignment.CENTER)
            .addComponent(pnlDtP3V, javax.swing.GroupLayout.Alignment.CENTER)
        );

        pnlDtP4.setOpaque(false);

        pnlDtP4K.setForeground(new java.awt.Color(100, 116, 139));
        pnlDtP4K.setText("Catatan");

        pnlDtP4V.setForeground(new java.awt.Color(15, 23, 42));
        pnlDtP4V.setText("Utamakan pengecekan sensor pintu.");

        javax.swing.GroupLayout pnlDtP4Layout = new javax.swing.GroupLayout(pnlDtP4);
        pnlDtP4.setLayout(pnlDtP4Layout);
        pnlDtP4Layout.setHorizontalGroup(
            pnlDtP4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtP4Layout.createSequentialGroup()
                .addComponent(pnlDtP4K, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(pnlDtP4V, javax.swing.GroupLayout.DEFAULT_SIZE, 228, Short.MAX_VALUE))
        );
        pnlDtP4Layout.setVerticalGroup(
            pnlDtP4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDtP4K, javax.swing.GroupLayout.Alignment.CENTER)
            .addComponent(pnlDtP4V, javax.swing.GroupLayout.Alignment.CENTER)
        );

        javax.swing.GroupLayout pnlDtPetugasLayout = new javax.swing.GroupLayout(pnlDtPetugas);
        pnlDtPetugas.setLayout(pnlDtPetugasLayout);
        pnlDtPetugasLayout.setHorizontalGroup(
            pnlDtPetugasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtPetugasLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(pnlDtPetugasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDtPetugasJudul, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtP1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtP2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtP3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtP4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );
        pnlDtPetugasLayout.setVerticalGroup(
            pnlDtPetugasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtPetugasLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(lblDtPetugasJudul)
                .addGap(10, 10, 10)
                .addComponent(pnlDtP1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(pnlDtP2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(pnlDtP3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(pnlDtP4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout pnlDtRowLayout = new javax.swing.GroupLayout(pnlDtRow);
        pnlDtRow.setLayout(pnlDtRowLayout);
        pnlDtRowLayout.setHorizontalGroup(
            pnlDtRowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtRowLayout.createSequentialGroup()
                .addComponent(pnlDtInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
                .addComponent(pnlDtPetugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        pnlDtRowLayout.setVerticalGroup(
            pnlDtRowLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlDtInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addComponent(pnlDtPetugas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pnlDtRiwayat.setBackground(new java.awt.Color(255, 255, 255));
        pnlDtRiwayat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(226, 232, 240)));

        lblDtRiwayatJudul.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblDtRiwayatJudul.setForeground(new java.awt.Color(15, 23, 42));
        lblDtRiwayatJudul.setText("Riwayat Progres");

        scr_tblRiwayat.setBackground(new java.awt.Color(255, 255, 255));
        scr_tblRiwayat.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(226, 232, 240)));

        tblRiwayat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"01 Nov 2026 10:05", "Pemeriksaan", "Pengecekan sensor dan rel pintu lift"},
                {"01 Nov 2026 14:30", "Perbaikan", "Penggantian sensor pintu"}
            },
            new String [] {
                "Waktu", "Status Progres", "Tindakan Penanganan"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblRiwayat.setForeground(new java.awt.Color(15, 23, 42));
        tblRiwayat.setRowHeight(40);
        tblRiwayat.setFillsViewportHeight(true);
        tblRiwayat.setGridColor(new java.awt.Color(226, 232, 240));
        tblRiwayat.setSelectionBackground(new java.awt.Color(219, 234, 254));
        tblRiwayat.setSelectionForeground(new java.awt.Color(15, 23, 42));
        scr_tblRiwayat.setViewportView(tblRiwayat);

        javax.swing.GroupLayout pnlDtRiwayatLayout = new javax.swing.GroupLayout(pnlDtRiwayat);
        pnlDtRiwayat.setLayout(pnlDtRiwayatLayout);
        pnlDtRiwayatLayout.setHorizontalGroup(
            pnlDtRiwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtRiwayatLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(pnlDtRiwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDtRiwayatJudul, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(scr_tblRiwayat))
                .addGap(20, 20, 20))
        );
        pnlDtRiwayatLayout.setVerticalGroup(
            pnlDtRiwayatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDtRiwayatLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(lblDtRiwayatJudul)
                .addGap(12, 12, 12)
                .addComponent(scr_tblRiwayat, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout pnlDetailLayout = new javax.swing.GroupLayout(pnlDetail);
        pnlDetail.setLayout(pnlDetailLayout);
        pnlDetailLayout.setHorizontalGroup(
            pnlDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDetailLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(pnlDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDetailJudul, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblDetailSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtToolbar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtRow, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlDtRiwayat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(32, 32, 32))
        );
        pnlDetailLayout.setVerticalGroup(
            pnlDetailLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDetailLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblDetailJudul)
                .addGap(4, 4, 4)
                .addComponent(lblDetailSub)
                .addGap(12, 12, 12)
                .addComponent(pnlDtToolbar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(pnlDtRow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(pnlDtRiwayat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        add(pnlDetail);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCariActionPerformed
        jalankanPencarian();
    }//GEN-LAST:event_btnCariActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        txtId.setText("");
        txtDari.setText("");
        txtSampai.setText("");
        txtFasilitas.setText("");
        cmbStatus.setSelectedIndex(0);
        cmbPrioritas.setSelectedIndex(0);
        cmbPetugas.setSelectedIndex(0);
        jalankanPencarian();
    }//GEN-LAST:event_btnResetActionPerformed

    private void btnKembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKembaliActionPerformed
        tampil("cari");
    }//GEN-LAST:event_btnKembaliActionPerformed

    private void tblHasilMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHasilMouseClicked
        if (klikAksi(tblHasil, evt)) {
            int baris = tblHasil.rowAtPoint(evt.getPoint());
            muatDetail(ViewHelper.angka(tblHasil.getValueAt(baris, 0)));
            tampil("detail");
        }
    }//GEN-LAST:event_tblHasilMouseClicked


    private void tampil(String kartu) {
        ((java.awt.CardLayout) getLayout()).show(this, kartu);
    }

    /** Menampilkan salah satu halaman di view ini (nama kartu: lihat Navigator). */
    public void tampilkan(String kartu) {
        if ("cari".equals(kartu)) {
            jalankanPencarian();
        }
        tampil(kartu);
    }

    /** true jika klik berada pada kolom terakhir (Aksi) sebuah baris tabel. */
    private static boolean klikAksi(javax.swing.JTable t, java.awt.event.MouseEvent evt) {
        return t.rowAtPoint(evt.getPoint()) >= 0 && t.columnAtPoint(evt.getPoint()) == t.getColumnCount() - 1;
    }

    /** true jika klik berada di sisi kiri sel Aksi (tautan pertama, mis. "Ubah"). */
    private static boolean klikTautanPertama(javax.swing.JTable t, java.awt.event.MouseEvent evt) {
        java.awt.Rectangle r = t.getCellRect(t.rowAtPoint(evt.getPoint()), t.getColumnCount() - 1, false);
        return evt.getX() - r.x < 52;
    }

    private String peran = "Admin";

    /** Peran: Admin, Supervisor atau Petugas (mengatur warna tombol dan filter Petugas). */
    public String getPeran() {
        return peran;
    }

    public void setPeran(String peran) {
        this.peran = peran;
        String warna = "2563EB";
        if ("Supervisor".equalsIgnoreCase(peran)) {
            warna = "7C3AED";
        } else if ("Petugas".equalsIgnoreCase(peran)) {
            warna = "EA580C";
        }
        btnCari.setBackground(java.awt.Color.decode("#" + warna));
        pnlKrPetugas.setVisible(!"Petugas".equalsIgnoreCase(peran));
        jalankanPencarian();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCari;
    private javax.swing.JButton btnKembali;
    private javax.swing.JButton btnReset;
    private javax.swing.JComboBox<String> cmbPetugas;
    private javax.swing.JComboBox<String> cmbPrioritas;
    private javax.swing.JComboBox<String> cmbStatus;
    private javax.swing.JLabel lblCariJudul;
    private javax.swing.JLabel lblCariSub;
    private javax.swing.JLabel lblDetailJudul;
    private javax.swing.JLabel lblDetailSub;
    private javax.swing.JLabel lblDtInfoJudul;
    private javax.swing.JLabel lblDtPetugasJudul;
    private javax.swing.JLabel lblDtRiwayatJudul;
    private javax.swing.JLabel lblInfo;
    private javax.swing.JLabel lblKrDari;
    private javax.swing.JLabel lblKrFas;
    private javax.swing.JLabel lblKrId;
    private javax.swing.JLabel lblKrPetugas;
    private javax.swing.JLabel lblKrPrioritas;
    private javax.swing.JLabel lblKrSampai;
    private javax.swing.JLabel lblKrSpasi;
    private javax.swing.JLabel lblKrStatus;
    private javax.swing.JLabel lblKriteriaJudul;
    private javax.swing.JPanel pnlCari;
    private javax.swing.JPanel pnlDetail;
    private javax.swing.JPanel pnlDtInfo;
    private javax.swing.JPanel pnlDtK1;
    private javax.swing.JLabel pnlDtK1K;
    private javax.swing.JLabel pnlDtK1V;
    private javax.swing.JPanel pnlDtK2;
    private javax.swing.JLabel pnlDtK2K;
    private javax.swing.JLabel pnlDtK2V;
    private javax.swing.JPanel pnlDtK3;
    private javax.swing.JLabel pnlDtK3K;
    private javax.swing.JLabel pnlDtK3V;
    private javax.swing.JPanel pnlDtK4;
    private javax.swing.JLabel pnlDtK4K;
    private javax.swing.JLabel pnlDtK4V;
    private javax.swing.JPanel pnlDtK5;
    private javax.swing.JLabel pnlDtK5K;
    private javax.swing.JLabel pnlDtK5V;
    private javax.swing.JPanel pnlDtK6;
    private javax.swing.JLabel pnlDtK6K;
    private javax.swing.JLabel pnlDtK6V;
    private javax.swing.JPanel pnlDtP1;
    private javax.swing.JLabel pnlDtP1K;
    private javax.swing.JLabel pnlDtP1V;
    private javax.swing.JPanel pnlDtP2;
    private javax.swing.JLabel pnlDtP2K;
    private javax.swing.JLabel pnlDtP2V;
    private javax.swing.JPanel pnlDtP3;
    private javax.swing.JLabel pnlDtP3K;
    private javax.swing.JLabel pnlDtP3V;
    private javax.swing.JPanel pnlDtP4;
    private javax.swing.JLabel pnlDtP4K;
    private javax.swing.JLabel pnlDtP4V;
    private javax.swing.JPanel pnlDtPetugas;
    private javax.swing.JPanel pnlDtRiwayat;
    private javax.swing.JPanel pnlDtRow;
    private javax.swing.JPanel pnlDtToolbar;
    private javax.swing.JPanel pnlKr1;
    private javax.swing.JPanel pnlKr2;
    private javax.swing.JPanel pnlKrCari;
    private javax.swing.JPanel pnlKrDari;
    private javax.swing.JPanel pnlKrFas;
    private javax.swing.JPanel pnlKrId;
    private javax.swing.JPanel pnlKrPetugas;
    private javax.swing.JPanel pnlKrPrioritas;
    private javax.swing.JPanel pnlKrSampai;
    private javax.swing.JPanel pnlKrStatus;
    private javax.swing.JPanel pnlKriteria;
    private javax.swing.JPanel pnlKriteriaHead;
    private javax.swing.JScrollPane scr_tblHasil;
    private javax.swing.JScrollPane scr_tblRiwayat;
    private javax.swing.JTable tblHasil;
    private javax.swing.JTable tblRiwayat;
    private javax.swing.JTextField txtDari;
    private javax.swing.JTextField txtFasilitas;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtSampai;
    // End of variables declaration//GEN-END:variables
}
