package dao;

import config.Koneksi;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

/**
 * Query khusus fitur Supervisor: dashboard, pantau progres, cari laporan, dan rekap.
 * Penambahan penugasan memakai PenugasanDAO, riwayat progres memakai ProgresPenangananDAO.
 */
public class SupervisorDAO {

    private interface Pemetaan<T> {
        T petakan(ResultSet rs) throws SQLException;
    }

    private <T> List<T> ambil(String sql, List<Object> param, Pemetaan<T> pemetaan) {
        List<T> hasil = new ArrayList<>();
        try (Connection conn = Koneksi.getConnection()) {
            if (conn == null) {
                return hasil;
            }
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                for (int i = 0; i < param.size(); i++) {
                    ps.setObject(i + 1, param.get(i));
                }
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        hasil.add(pemetaan.petakan(rs));
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Query supervisor gagal: " + e.getMessage());
        }
        return hasil;
    }

    private static void periode(StringBuilder sql, List<Object> param, String kolom, Date awal, Date akhir) {
        if (awal != null) {
            sql.append(" AND ").append(kolom).append(" >= ?");
            param.add(awal);
        }
        if (akhir != null) {
            sql.append(" AND ").append(kolom).append(" <= ?");
            param.add(akhir);
        }
    }

    private static final String PETUGAS_LAPORAN
            = "(SELECT GROUP_CONCAT(pg.nama_lengkap ORDER BY dp.id_detail SEPARATOR ', ') "
            + "FROM penugasan p "
            + "JOIN detail_penugasan dp ON dp.PENUGASAN_id_penugasan = p.id_penugasan "
            + "JOIN pengguna pg ON pg.id_pengguna = dp.PETUGAS_id_pengguna "
            + "WHERE p.LAPORAN_KERUSAKAN_id_laporan = lr.id_laporan "
            + "AND dp.status_keterlibatan <> 'Digantikan')";

    // ===================== DASHBOARD =====================

    /** Kunci: menunggu, berjalan, selesaiBulanIni, petugasAktif. */
    public Map<String, Integer> getRingkasanDashboard() {
        Map<String, Integer> data = new LinkedHashMap<>();
        data.put("menunggu", 0);
        data.put("berjalan", 0);
        data.put("selesaiBulanIni", 0);
        data.put("petugasAktif", 0);

        String sql = "SELECT "
                + "(SELECT COUNT(*) FROM laporan_kerusakan lr WHERE lr.status = 'Menunggu' "
                + " AND NOT EXISTS (SELECT 1 FROM penugasan p "
                + "  WHERE p.LAPORAN_KERUSAKAN_id_laporan = lr.id_laporan)) AS menunggu, "
                + "(SELECT COUNT(*) FROM laporan_kerusakan WHERE status = 'Diproses') AS berjalan, "
                + "(SELECT COUNT(DISTINCT lr.id_laporan) FROM laporan_kerusakan lr "
                + " JOIN penugasan p ON p.LAPORAN_KERUSAKAN_id_laporan = lr.id_laporan "
                + " JOIN progres_penanganan pp ON pp.PENUGASAN_id_penugasan = p.id_penugasan "
                + " WHERE lr.status = 'Selesai' AND pp.status_progres = 'Selesai' "
                + " AND YEAR(pp.waktu_update) = YEAR(CURDATE()) "
                + " AND MONTH(pp.waktu_update) = MONTH(CURDATE())) AS selesai, "
                + "(SELECT COUNT(*) FROM pengguna WHERE peran = 'Petugas' "
                + " AND status_aktif = 'Aktif') AS petugas";

        List<int[]> baris = ambil(sql, new ArrayList<>(), rs -> new int[]{
            rs.getInt("menunggu"), rs.getInt("berjalan"),
            rs.getInt("selesai"), rs.getInt("petugas")});
        if (!baris.isEmpty()) {
            int[] b = baris.get(0);
            data.put("menunggu", b[0]);
            data.put("berjalan", b[1]);
            data.put("selesaiBulanIni", b[2]);
            data.put("petugasAktif", b[3]);
        }
        return data;
    }

    // ===================== PANTAU PROGRES =====================

    /** Baris: idPenugasan, waktu(Date), petugas, fasilitas, statusLaporan, progresTerakhir(atau null). */
    public List<Object[]> getDaftarPantau() {
        String sql = "SELECT p.id_penugasan, p.waktu_penugasan, "
                + "(SELECT GROUP_CONCAT(pg.nama_lengkap ORDER BY dp.id_detail SEPARATOR ', ') "
                + " FROM detail_penugasan dp JOIN pengguna pg ON pg.id_pengguna = dp.PETUGAS_id_pengguna "
                + " WHERE dp.PENUGASAN_id_penugasan = p.id_penugasan "
                + " AND dp.status_keterlibatan <> 'Digantikan') AS petugas, "
                + "f.nama_fasilitas, lr.status, "
                + "(SELECT pp.status_progres FROM progres_penanganan pp "
                + " WHERE pp.PENUGASAN_id_penugasan = p.id_penugasan "
                + " ORDER BY pp.waktu_update DESC, pp.id_progres DESC LIMIT 1) AS progres "
                + "FROM penugasan p "
                + "JOIN laporan_kerusakan lr ON lr.id_laporan = p.LAPORAN_KERUSAKAN_id_laporan "
                + "JOIN fasilitas f ON f.id_fasilitas = lr.FASILITAS_id_fasilitas "
                + "ORDER BY p.id_penugasan DESC";
        return ambil(sql, new ArrayList<>(), rs -> new Object[]{
            rs.getInt("id_penugasan"), rs.getDate("waktu_penugasan"),
            rs.getString("petugas"), rs.getString("nama_fasilitas"),
            rs.getString("status"), rs.getString("progres")});
    }

    /** {namaFasilitas, "Agus (utama), Dewi"} untuk judul riwayat progres. Null bila tidak ada. */
    public String[] getInfoPenugasan(int idPenugasan) {
        String sql = "SELECT f.nama_fasilitas, "
                + "(SELECT GROUP_CONCAT(CONCAT(pg.nama_lengkap, "
                + "   IF(pg.id_pengguna = p.id_pengguna, ' (utama)', '')) "
                + "   ORDER BY dp.id_detail SEPARATOR ', ') "
                + " FROM detail_penugasan dp JOIN pengguna pg ON pg.id_pengguna = dp.PETUGAS_id_pengguna "
                + " WHERE dp.PENUGASAN_id_penugasan = p.id_penugasan "
                + " AND dp.status_keterlibatan <> 'Digantikan') AS petugas "
                + "FROM penugasan p "
                + "JOIN laporan_kerusakan lr ON lr.id_laporan = p.LAPORAN_KERUSAKAN_id_laporan "
                + "JOIN fasilitas f ON f.id_fasilitas = lr.FASILITAS_id_fasilitas "
                + "WHERE p.id_penugasan = ?";
        List<Object> param = new ArrayList<>();
        param.add(idPenugasan);
        List<String[]> hasil = ambil(sql, param, rs -> new String[]{
            rs.getString("nama_fasilitas"), rs.getString("petugas")});
        return hasil.isEmpty() ? null : hasil.get(0);
    }

    // ===================== CARI LAPORAN =====================

    /** Daftar semua petugas: {id, nama}. */
    public List<Object[]> getDaftarPetugas() {
        String sql = "SELECT pg.id_pengguna, pg.nama_lengkap FROM pengguna pg "
                + "JOIN petugas pt ON pt.id_pengguna = pg.id_pengguna "
                + "ORDER BY pg.nama_lengkap";
        return ambil(sql, new ArrayList<>(), rs -> new Object[]{
            rs.getInt(1), rs.getString(2)});
    }

    /**
     * Semua kriteria boleh null/kosong (tidak difilter).
     * batasPetugas: bila bukan null, hanya laporan pada penugasan petugas itu (akses peran Petugas).
     * Baris: idLaporan, tanggal(Date), fasilitas, prioritas, status, petugas(atau null).
     */
    public List<Object[]> cariLaporan(Integer idLaporan, Date dari, Date sampai, String kata,
            String status, String prioritas, Integer idPetugas, Integer batasPetugas) {

        StringBuilder sql = new StringBuilder(
                "SELECT lr.id_laporan, lr.tanggal_laporan, f.nama_fasilitas, lr.prioritas, lr.status, "
                + PETUGAS_LAPORAN + " AS petugas "
                + "FROM laporan_kerusakan lr "
                + "JOIN fasilitas f ON f.id_fasilitas = lr.FASILITAS_id_fasilitas WHERE 1 = 1");
        List<Object> param = new ArrayList<>();

        if (idLaporan != null) {
            sql.append(" AND lr.id_laporan = ?");
            param.add(idLaporan);
        }
        periode(sql, param, "lr.tanggal_laporan", dari, sampai);
        if (kata != null && !kata.trim().isEmpty()) {
            sql.append(" AND (f.nama_fasilitas LIKE ? OR f.lokasi LIKE ?)");
            param.add("%" + kata.trim() + "%");
            param.add("%" + kata.trim() + "%");
        }
        if (status != null) {
            sql.append(" AND lr.status = ?");
            param.add(status);
        }
        if (prioritas != null) {
            sql.append(" AND lr.prioritas = ?");
            param.add(prioritas);
        }
        for (Integer petugas : new Integer[]{idPetugas, batasPetugas}) {
            if (petugas != null) {
                sql.append(" AND EXISTS (SELECT 1 FROM penugasan p "
                        + "JOIN detail_penugasan dp ON dp.PENUGASAN_id_penugasan = p.id_penugasan "
                        + "WHERE p.LAPORAN_KERUSAKAN_id_laporan = lr.id_laporan "
                        + "AND dp.PETUGAS_id_pengguna = ?)");
                param.add(petugas);
            }
        }
        sql.append(" ORDER BY lr.id_laporan DESC");

        return ambil(sql.toString(), param, rs -> new Object[]{
            rs.getInt("id_laporan"), rs.getDate("tanggal_laporan"),
            rs.getString("nama_fasilitas"), rs.getString("prioritas"),
            rs.getString("status"), rs.getString("petugas")});
    }

    /** {idLaporan, tanggal, fasilitas, lokasi, deskripsi, prioritas, status, petugas}. Null bila tidak ada. */
    public Object[] getDetailLaporan(int idLaporan) {
        String sql = "SELECT lr.id_laporan, lr.tanggal_laporan, f.nama_fasilitas, f.lokasi, "
                + "lr.deskripsi_kerusakan, lr.prioritas, lr.status, " + PETUGAS_LAPORAN + " AS petugas "
                + "FROM laporan_kerusakan lr "
                + "JOIN fasilitas f ON f.id_fasilitas = lr.FASILITAS_id_fasilitas "
                + "WHERE lr.id_laporan = ?";
        List<Object> param = new ArrayList<>();
        param.add(idLaporan);
        List<Object[]> hasil = ambil(sql, param, rs -> new Object[]{
            rs.getInt(1), rs.getDate(2), rs.getString(3), rs.getString(4),
            rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)});
        return hasil.isEmpty() ? null : hasil.get(0);
    }

    /** Riwayat progres seluruh penugasan sebuah laporan: {waktu(Timestamp), status, tindakan}. */
    public List<Object[]> getRiwayatLaporan(int idLaporan) {
        String sql = "SELECT pp.waktu_update, pp.status_progres, pp.tindakan_penanganan "
                + "FROM progres_penanganan pp "
                + "JOIN penugasan p ON p.id_penugasan = pp.PENUGASAN_id_penugasan "
                + "WHERE p.LAPORAN_KERUSAKAN_id_laporan = ? "
                + "ORDER BY pp.waktu_update, pp.id_progres";
        List<Object> param = new ArrayList<>();
        param.add(idLaporan);
        return ambil(sql, param, rs -> new Object[]{
            rs.getTimestamp(1), rs.getString(2), rs.getString(3)});
    }

    // ===================== REKAP LAPORAN =====================

    /** [menunggu, diproses, selesai] pada periode (null = semua). */
    public int[] hitungPerStatus(Date awal, Date akhir) {
        return hitungPer("status", new String[]{"Menunggu", "Diproses", "Selesai"}, awal, akhir);
    }

    /** [tinggi, sedang, rendah] pada periode (null = semua). */
    public int[] hitungPerPrioritas(Date awal, Date akhir) {
        return hitungPer("prioritas", new String[]{"Tinggi", "Sedang", "Rendah"}, awal, akhir);
    }

    private int[] hitungPer(String kolom, String[] nilai, Date awal, Date akhir) {
        StringBuilder sql = new StringBuilder(
                "SELECT lr." + kolom + ", COUNT(*) FROM laporan_kerusakan lr WHERE 1 = 1");
        List<Object> param = new ArrayList<>();
        periode(sql, param, "lr.tanggal_laporan", awal, akhir);
        sql.append(" GROUP BY lr.").append(kolom);

        int[] hasil = new int[nilai.length];
        for (Object[] b : ambil(sql.toString(), param, rs -> new Object[]{rs.getString(1), rs.getInt(2)})) {
            for (int i = 0; i < nilai.length; i++) {
                if (nilai[i].equals(b[0])) {
                    hasil[i] = (Integer) b[1];
                }
            }
        }
        return hasil;
    }

    /** Fasilitas dengan 2 laporan atau lebih: {idFasilitas, nama, jenis, jumlah}. */
    public List<Object[]> getFasilitasBerulang(Date awal, Date akhir) {
        StringBuilder sql = new StringBuilder(
                "SELECT f.id_fasilitas, f.nama_fasilitas, f.jenis_fasilitas, COUNT(*) AS jumlah "
                + "FROM laporan_kerusakan lr "
                + "JOIN fasilitas f ON f.id_fasilitas = lr.FASILITAS_id_fasilitas WHERE 1 = 1");
        List<Object> param = new ArrayList<>();
        periode(sql, param, "lr.tanggal_laporan", awal, akhir);
        sql.append(" GROUP BY f.id_fasilitas, f.nama_fasilitas, f.jenis_fasilitas "
                + "HAVING COUNT(*) >= 2 ORDER BY jumlah DESC, f.nama_fasilitas LIMIT 10");
        return ambil(sql.toString(), param, rs -> new Object[]{
            rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4)});
    }

    /** Beban per petugas: {nama, jumlahPenugasan, laporanDitangani (laporan yang sudah punya progres)}. */
    public List<Object[]> getBebanPetugas(Date awal, Date akhir) {
        StringBuilder sql = new StringBuilder(
                "SELECT pg.nama_lengkap, COUNT(DISTINCT p.id_penugasan) AS jml_tugas, "
                + "COUNT(DISTINCT CASE WHEN EXISTS (SELECT 1 FROM progres_penanganan x "
                + "  WHERE x.PENUGASAN_id_penugasan = p.id_penugasan) THEN lr.id_laporan END) AS ditangani "
                + "FROM detail_penugasan dp "
                + "JOIN pengguna pg ON pg.id_pengguna = dp.PETUGAS_id_pengguna "
                + "JOIN penugasan p ON p.id_penugasan = dp.PENUGASAN_id_penugasan "
                + "JOIN laporan_kerusakan lr ON lr.id_laporan = p.LAPORAN_KERUSAKAN_id_laporan "
                + "WHERE 1 = 1");
        List<Object> param = new ArrayList<>();
        periode(sql, param, "lr.tanggal_laporan", awal, akhir);
        sql.append(" GROUP BY pg.id_pengguna, pg.nama_lengkap ORDER BY jml_tugas DESC, pg.nama_lengkap");
        return ambil(sql.toString(), param, rs -> new Object[]{
            rs.getString(1), rs.getInt(2), rs.getInt(3)});
    }

    /** Rata-rata hari: waktu_update progres Selesai dikurangi tanggal_laporan. Null bila belum ada. */
    public Double getRataWaktuPenyelesaian(Date awal, Date akhir) {
        StringBuilder sql = new StringBuilder(
                "SELECT AVG(DATEDIFF(x.selesai, x.tgl)) FROM ("
                + "SELECT lr.id_laporan, lr.tanggal_laporan AS tgl, MAX(pp.waktu_update) AS selesai "
                + "FROM laporan_kerusakan lr "
                + "JOIN penugasan p ON p.LAPORAN_KERUSAKAN_id_laporan = lr.id_laporan "
                + "JOIN progres_penanganan pp ON pp.PENUGASAN_id_penugasan = p.id_penugasan "
                + "WHERE pp.status_progres = 'Selesai'");
        List<Object> param = new ArrayList<>();
        periode(sql, param, "lr.tanggal_laporan", awal, akhir);
        sql.append(" GROUP BY lr.id_laporan, lr.tanggal_laporan) x");
        List<Double> hasil = ambil(sql.toString(), param, rs -> {
            double nilai = rs.getDouble(1);
            return rs.wasNull() ? null : nilai;
        });
        return hasil.isEmpty() ? null : hasil.get(0);
    }

    /** {namaFasilitas, lokasi}. Null bila tidak ada. */
    public String[] getInfoFasilitas(int idFasilitas) {
        List<Object> param = new ArrayList<>();
        param.add(idFasilitas);
        List<String[]> hasil = ambil(
                "SELECT nama_fasilitas, lokasi FROM fasilitas WHERE id_fasilitas = ?",
                param, rs -> new String[]{rs.getString(1), rs.getString(2)});
        return hasil.isEmpty() ? null : hasil.get(0);
    }

    /** Riwayat gangguan satu fasilitas: {idLaporan, tanggal, deskripsi, status, tindakanTerakhir(atau null)}. */
    public List<Object[]> getRiwayatGangguan(int idFasilitas, Date awal, Date akhir) {
        StringBuilder sql = new StringBuilder(
                "SELECT lr.id_laporan, lr.tanggal_laporan, lr.deskripsi_kerusakan, lr.status, "
                + "(SELECT pp.tindakan_penanganan FROM progres_penanganan pp "
                + " JOIN penugasan p ON p.id_penugasan = pp.PENUGASAN_id_penugasan "
                + " WHERE p.LAPORAN_KERUSAKAN_id_laporan = lr.id_laporan "
                + " ORDER BY pp.waktu_update DESC, pp.id_progres DESC LIMIT 1) AS tindakan "
                + "FROM laporan_kerusakan lr WHERE lr.FASILITAS_id_fasilitas = ?");
        List<Object> param = new ArrayList<>();
        param.add(idFasilitas);
        periode(sql, param, "lr.tanggal_laporan", awal, akhir);
        sql.append(" ORDER BY lr.tanggal_laporan DESC, lr.id_laporan DESC");
        return ambil(sql.toString(), param, rs -> new Object[]{
            rs.getInt(1), rs.getDate(2), rs.getString(3), rs.getString(4), rs.getString(5)});
    }
}
