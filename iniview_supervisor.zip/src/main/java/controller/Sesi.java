package controller;

import model.Pengguna;

/**
 * Menyimpan pengguna yang sedang login selama aplikasi berjalan.
 * Dipakai view untuk mengambil id_pengguna (mis. SUPERVISOR_id_pengguna).
 */
public final class Sesi {

    private static Pengguna pengguna;

    private Sesi() {
    }

    public static void mulai(Pengguna p) {
        pengguna = p;
    }

    public static void hapus() {
        pengguna = null;
    }

    public static boolean adaSesi() {
        return pengguna != null;
    }

    public static Pengguna getPengguna() {
        return pengguna;
    }

    public static int getId() {
        return pengguna == null ? 0 : pengguna.getIdPengguna();
    }

    public static String getNama() {
        return pengguna == null ? "" : pengguna.getNamaLengkap();
    }

    public static String getPeran() {
        return pengguna == null ? "" : pengguna.getPeran();
    }
}
