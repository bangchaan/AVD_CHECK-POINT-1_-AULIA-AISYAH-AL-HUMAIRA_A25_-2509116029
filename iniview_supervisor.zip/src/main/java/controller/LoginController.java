package controller;

import dao.PenggunaDAO;
import model.Pengguna;

public class LoginController {

    private final PenggunaDAO penggunaDAO;

    public LoginController() {
        penggunaDAO = new PenggunaDAO();
    }

    public Pengguna prosesLogin(String username, String password) {

        if (username == null || username.trim().isEmpty()
                || password == null || password.trim().isEmpty()) {
            return null;
        }

        try {
            Pengguna pengguna = penggunaDAO.login(username.trim(), password);
            if (pengguna != null) {
                Sesi.mulai(pengguna);
            }
            return pengguna;
        } catch (RuntimeException e) {
            // mis. koneksi database tidak tersedia
            System.out.println("Login gagal: " + e.getMessage());
            return null;
        }
    }
}