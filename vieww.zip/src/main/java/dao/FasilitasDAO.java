package dao;

import config.Koneksi;
import model.Fasilitas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Akses data tabel FASILITAS untuk fitur Admin (Kelola Data Fasilitas).
 * Batas kolom mengikuti skema database:
 * nama 30, jenis 30, lokasi 50, keterangan 60.
 */
public class FasilitasDAO {

    private static final String KOLOM
            = "f.id_fasilitas, f.nama_fasilitas, f.jenis_fasilitas, "
            + "f.lokasi, f.kondisi, f.keterangan, f.ADMIN_id_pengguna";

    // READ: seluruh fasilitas
    public List<Fasilitas> getAllFasilitas() {
        return cariFasilitas(null);
    }

    // READ + SEARCH: nama, jenis, lokasi, kondisi, keterangan, atau ID
    public List<Fasilitas> cariFasilitas(String keyword) {
        List<Fasilitas> daftar = new ArrayList<>();

        String sql = "SELECT " + KOLOM + " FROM fasilitas f ";
        boolean pakaiFilter = keyword != null && !keyword.trim().isEmpty();

        if (pakaiFilter) {
            sql += "WHERE CAST(f.id_fasilitas AS CHAR) LIKE ? "
                    + "OR f.nama_fasilitas LIKE ? "
                    + "OR f.jenis_fasilitas LIKE ? "
                    + "OR f.lokasi LIKE ? "
                    + "OR f.kondisi LIKE ? "
                    + "OR f.keterangan LIKE ? ";
        }
        sql += "ORDER BY f.id_fasilitas ASC";

        try (Connection conn = Koneksi.getConnection()) {
            if (conn == null) {
                return daftar;
            }
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                if (pakaiFilter) {
                    String p = "%" + keyword.trim() + "%";
                    for (int i = 1; i <= 6; i++) {
                        ps.setString(i, p);
                    }
                }
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        daftar.add(ambilData(rs));
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Gagal mengambil data fasilitas: " + e.getMessage());
        }

        return daftar;
    }

    // READ: satu fasilitas berdasarkan ID (null bila tidak ditemukan)
    public Fasilitas getFasilitasById(int idFasilitas) {
        String sql = "SELECT " + KOLOM + " FROM fasilitas f "
                + "WHERE f.id_fasilitas = ?";

        try (Connection conn = Koneksi.getConnection()) {
            if (conn == null) {
                return null;
            }
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idFasilitas);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return ambilData(rs);
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Gagal mengambil fasilitas: " + e.getMessage());
        }

        return null;
    }

    // CREATE
    public boolean tambahFasilitas(Fasilitas f) {
        if (!validasi(f) || f.getAdminIdPengguna() <= 0) {
            return false;
        }

        String sql = "INSERT INTO fasilitas "
                + "(nama_fasilitas, jenis_fasilitas, lokasi, kondisi, "
                + "keterangan, ADMIN_id_pengguna) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = Koneksi.getConnection()) {
            if (conn == null) {
                return false;
            }
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, f.getNamaFasilitas().trim());
                ps.setString(2, f.getJenisFasilitas().trim());
                ps.setString(3, f.getLokasi().trim());
                ps.setString(4, f.getKondisi());
                isiKeterangan(ps, 5, f.getKeterangan());
                ps.setInt(6, f.getAdminIdPengguna());

                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.out.println("Gagal menambahkan fasilitas: " + e.getMessage());
            return false;
        }
    }

    // UPDATE: ADMIN_id_pengguna (pencatat awal) tidak diubah
    public boolean updateFasilitas(Fasilitas f) {
        if (f == null || f.getIdFasilitas() <= 0 || !validasi(f)) {
            return false;
        }

        String sql = "UPDATE fasilitas SET nama_fasilitas = ?, "
                + "jenis_fasilitas = ?, lokasi = ?, kondisi = ?, "
                + "keterangan = ? WHERE id_fasilitas = ?";

        try (Connection conn = Koneksi.getConnection()) {
            if (conn == null) {
                return false;
            }
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, f.getNamaFasilitas().trim());
                ps.setString(2, f.getJenisFasilitas().trim());
                ps.setString(3, f.getLokasi().trim());
                ps.setString(4, f.getKondisi());
                isiKeterangan(ps, 5, f.getKeterangan());
                ps.setInt(6, f.getIdFasilitas());

                // executeUpdate() bernilai 0 bila data tidak berubah di sebagian
                // konfigurasi MySQL, sehingga cukup pastikan tidak error.
                ps.executeUpdate();
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Gagal memperbarui fasilitas: " + e.getMessage());
            return false;
        }
    }

    // true bila fasilitas sudah dipakai di LAPORAN_KERUSAKAN
    public boolean punyaRiwayatLaporan(int idFasilitas) {
        String sql = "SELECT 1 FROM laporan_kerusakan "
                + "WHERE FASILITAS_id_fasilitas = ? LIMIT 1";

        try (Connection conn = Koneksi.getConnection()) {
            if (conn == null) {
                return true; // gagal koneksi: anggap tidak aman dihapus
            }
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idFasilitas);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next();
                }
            }
        } catch (SQLException e) {
            System.out.println("Gagal memeriksa riwayat laporan: " + e.getMessage());
            return true;
        }
    }

    // DELETE: hanya bila fasilitas belum pernah dipakai di laporan kerusakan
    public boolean hapusFasilitas(int idFasilitas) {
        if (idFasilitas <= 0) {
            return false;
        }

        String sql = "DELETE FROM fasilitas WHERE id_fasilitas = ? "
                + "AND NOT EXISTS (SELECT 1 FROM laporan_kerusakan lr "
                + "WHERE lr.FASILITAS_id_fasilitas = fasilitas.id_fasilitas)";

        try (Connection conn = Koneksi.getConnection()) {
            if (conn == null) {
                return false;
            }
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setInt(1, idFasilitas);
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.out.println("Gagal menghapus fasilitas: " + e.getMessage());
            return false;
        }
    }

    // Jenis fasilitas yang sudah ada (untuk isi pilihan di form)
    public List<String> getDaftarJenis() {
        List<String> daftar = new ArrayList<>();
        String sql = "SELECT DISTINCT jenis_fasilitas FROM fasilitas "
                + "ORDER BY jenis_fasilitas ASC";

        try (Connection conn = Koneksi.getConnection()) {
            if (conn == null) {
                return daftar;
            }
            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    daftar.add(rs.getString(1));
                }
            }
        } catch (SQLException e) {
            System.out.println("Gagal mengambil jenis fasilitas: " + e.getMessage());
        }

        return daftar;
    }

    private void isiKeterangan(PreparedStatement ps, int indeks, String ket)
            throws SQLException {
        if (ket == null || ket.trim().isEmpty()) {
            ps.setNull(indeks, java.sql.Types.VARCHAR);
        } else {
            ps.setString(indeks, ket.trim());
        }
    }

    private Fasilitas ambilData(ResultSet rs) throws SQLException {
        Fasilitas f = new Fasilitas();
        f.setIdFasilitas(rs.getInt("id_fasilitas"));
        f.setNamaFasilitas(rs.getString("nama_fasilitas"));
        f.setJenisFasilitas(rs.getString("jenis_fasilitas"));
        f.setLokasi(rs.getString("lokasi"));
        f.setKondisi(rs.getString("kondisi"));
        f.setKeterangan(rs.getString("keterangan"));
        f.setAdminIdPengguna(rs.getInt("ADMIN_id_pengguna"));
        return f;
    }

    private boolean validasi(Fasilitas f) {
        if (f == null) {
            return false;
        }

        String nama = f.getNamaFasilitas();
        String jenis = f.getJenisFasilitas();
        String lokasi = f.getLokasi();
        String kondisi = f.getKondisi();
        String ket = f.getKeterangan();

        boolean kondisiValid = "Baik".equals(kondisi)
                || "Rusak".equals(kondisi)
                || "Perlu Perbaikan".equals(kondisi);

        return nama != null && !nama.trim().isEmpty() && nama.trim().length() <= 30
                && jenis != null && !jenis.trim().isEmpty() && jenis.trim().length() <= 30
                && lokasi != null && !lokasi.trim().isEmpty() && lokasi.trim().length() <= 50
                && kondisiValid
                && (ket == null || ket.trim().length() <= 60);
    }
}
