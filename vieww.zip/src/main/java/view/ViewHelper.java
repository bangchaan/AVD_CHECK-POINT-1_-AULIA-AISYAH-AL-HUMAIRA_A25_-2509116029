package view;

import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Container;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

/**
 * Helper pendukung tampilan (format tanggal/kode, penamaan kartu CardLayout).
 * Bukan form, jadi boleh berupa Java class biasa di package view.
 */
public final class ViewHelper {

    private static final Locale ID = Locale.forLanguageTag("id-ID");
    private static final String[] POLA_TANGGAL = {
        "dd MMM yyyy", "d MMM yyyy", "yyyy-MM-dd", "dd/MM/yyyy", "dd-MM-yyyy"
    };

    private ViewHelper() {
    }

    public static String tanggal(java.util.Date d) {
        return d == null ? "-" : new SimpleDateFormat("dd MMM yyyy", ID).format(d);
    }

    public static String waktu(java.util.Date d) {
        return d == null ? "-" : new SimpleDateFormat("dd MMM yyyy HH:mm", ID).format(d);
    }

    public static String kodeLaporan(int id) {
        return String.format("L-%04d", id);
    }

    public static String kodeTugas(int id) {
        return String.format("T-%03d", id);
    }

    /** Mengambil angka dari teks seperti "L-0105" atau "T-021". Mengembalikan -1 bila tidak ada. */
    public static int angka(Object teks) {
        if (teks == null) {
            return -1;
        }
        String digit = teks.toString().replaceAll("\\D", "");
        if (digit.isEmpty() || digit.length() > 9) {
            return -1;
        }
        return Integer.parseInt(digit);
    }

    /** Teks kosong menghasilkan null. Format salah melempar IllegalArgumentException. */
    public static Date parseTanggal(String teks) {
        if (teks == null || teks.trim().isEmpty()) {
            return null;
        }
        String t = teks.trim();
        for (String pola : POLA_TANGGAL) {
            SimpleDateFormat f = new SimpleDateFormat(pola, ID);
            f.setLenient(false);
            try {
                return new Date(f.parse(t).getTime());
            } catch (ParseException e) {
                // coba pola berikutnya
            }
        }
        throw new IllegalArgumentException("Format tanggal tidak dikenali: " + t);
    }

    /**
     * Form dari GUI Builder menambahkan kartu tanpa nama, sehingga CardLayout.show(...)
     * tidak berpengaruh. Method ini memberi nama pada kartu sesuai urutan penambahannya.
     */
    public static void namaiKartu(Container c, String... nama) {
        Component[] kartu = c.getComponents();
        if (!(c.getLayout() instanceof CardLayout) || kartu.length != nama.length) {
            return;
        }
        c.removeAll();
        for (int i = 0; i < kartu.length; i++) {
            c.add(kartu[i], nama[i]);
        }
        ((CardLayout) c.getLayout()).show(c, nama[0]);
    }

    public static String kodePengguna(int id) {
        return String.format("P%03d", id);
    }

    public static String kodeFasilitas(int id) {
        return String.format("F%03d", id);
    }

    /** Membatasi jumlah karakter sebuah komponen teks (mis. deskripsi maks. 150). */
    public static void batasiPanjang(javax.swing.text.JTextComponent komponen, int maks) {
        ((javax.swing.text.AbstractDocument) komponen.getDocument())
                .setDocumentFilter(new javax.swing.text.DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String teks,
                    javax.swing.text.AttributeSet attr)
                    throws javax.swing.text.BadLocationException {
                if (teks == null) {
                    return;
                }
                int sisa = maks - fb.getDocument().getLength();
                if (sisa > 0) {
                    super.insertString(fb, offset,
                            teks.length() > sisa ? teks.substring(0, sisa) : teks, attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int panjang, String teks,
                    javax.swing.text.AttributeSet attr)
                    throws javax.swing.text.BadLocationException {
                int sisa = maks - (fb.getDocument().getLength() - panjang);
                if (teks == null || sisa <= 0) {
                    if (teks == null || teks.isEmpty()) {
                        super.replace(fb, offset, panjang, teks, attr);
                    }
                    return;
                }
                super.replace(fb, offset, panjang,
                        teks.length() > sisa ? teks.substring(0, sisa) : teks, attr);
            }
        });
    }

    /** Menjalankan aksi setiap isi komponen teks berubah (ketik/hapus/tempel). */
    public static void saatBerubah(javax.swing.text.JTextComponent komponen, Runnable aksi) {
        komponen.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                aksi.run();
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                aksi.run();
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                aksi.run();
            }
        });
    }
}
